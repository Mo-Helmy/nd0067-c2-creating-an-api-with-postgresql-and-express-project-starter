DROP TABLE orders;

DROP TYPE status;