"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const produts_1 = require("../../controllers/produts");
const authenticate_1 = __importDefault(require("../../middleware/authenticate"));
const productsRoute = express_1.default.Router();
// get all products
// OR get all products by query category '/api/products?category=cat1'
productsRoute.get('/', produts_1.getAllProducts);
//Top 5 popular products (add query limit 'api/procucts/popular?limit=5')
productsRoute.get('/popular', produts_1.getTopProducts);
//show product by id
productsRoute.get('/:productId', produts_1.getProductById);
//create new product
productsRoute.post('/', authenticate_1.default, produts_1.postNewProduct);
//update product
productsRoute.put('/:productId', authenticate_1.default, produts_1.putProduct);
//delete product by id
productsRoute.delete('/:productId', authenticate_1.default, produts_1.deleteProductById);
exports.default = productsRoute;
