"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const orders_1 = require("../../controllers/orders");
const authenticate_1 = __importDefault(require("../../middleware/authenticate"));
const autherization_1 = __importDefault(require("../../middleware/autherization"));
const ordersRoute = express_1.default.Router();
//index
ordersRoute.get('/', orders_1.getAllOrders);
//create
ordersRoute.post('/', autherization_1.default, orders_1.postNewOrder);
//read
ordersRoute.get('/:orderId', orders_1.getOrderById);
//update
ordersRoute.put('/:orderId', orders_1.putOrder);
//delete
ordersRoute.delete('/:orderId', orders_1.deleteOrderById);
//index all products by orderId
ordersRoute.get('/:orderId/products', authenticate_1.default, orders_1.getProductsByOrderId);
//add products by orderId
ordersRoute.post('/:orderId/products', authenticate_1.default, orders_1.postProductByOrderId);
exports.default = ordersRoute;
