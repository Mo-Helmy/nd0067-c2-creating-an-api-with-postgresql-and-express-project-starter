import express from 'express';
import {
  deleteOrderById,
  getAllOrders,
  getOrderById,
  getProductsByOrderId,
  postNewOrder,
  postProductByOrderId,
  putOrder
} from '../../controllers/orders';
import authenticate from '../../middleware/authenticate';
import autherization from '../../middleware/autherization';

const ordersRoute = express.Router();

//index
ordersRoute.get('/', getAllOrders);
//create
ordersRoute.post('/', autherization, postNewOrder);
//read
ordersRoute.get('/:orderId', getOrderById);
//update
ordersRoute.put('/:orderId', putOrder);
//delete
ordersRoute.delete('/:orderId', deleteOrderById);

//index all products by orderId
ordersRoute.get('/:orderId/products', authenticate, getProductsByOrderId);
//add products by orderId
ordersRoute.post('/:orderId/products', authenticate, postProductByOrderId);

export default ordersRoute;
