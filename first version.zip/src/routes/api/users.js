"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const users_1 = require("../../controllers/users");
const authenticate_1 = __importDefault(require("../../middleware/authenticate"));
const autherization_1 = __importDefault(require("../../middleware/autherization"));
// import { getOrdersAndProductsByUserId } from '../../services/orders';
const usersRoute = express_1.default.Router();
//show all users
usersRoute.get('/', authenticate_1.default, users_1.getAllUsers);
//create new user (will generate new token)
usersRoute.post('/', users_1.createUser);
//auth user (will generate new token)
usersRoute.post('/auth', users_1.authUser);
//show user by userId
usersRoute.get('/:userId', autherization_1.default, users_1.getUserById);
//show user orders by userId
// and
//show orders by status query for userId '/:userId/orders/status?status=active'
usersRoute.get('/:userId/orders', autherization_1.default, users_1.getOrdersByUserId);
//show order products by userId for each orderId
usersRoute.get('/:userId/orders/:orderId', autherization_1.default, users_1.getProductsByOrderId);
exports.default = usersRoute;
