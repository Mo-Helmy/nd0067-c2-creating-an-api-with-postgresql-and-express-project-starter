import UserStore, { User } from '../../models/user';
import jwt, { JwtPayload } from 'jsonwebtoken';

const store = new UserStore();
let user1: User;
let user2: User;
let token1: string;
let token2: string;
let authUser1: { token: string; authUser: User };
let authUser2: { token: string; authUser: User };

describe('test user store model', () => {
  it('create new user', async () => {
    token1 = await store.create({
      username: 'mohelmy',
      firstName: 'mo',
      lastName: 'helmy',
      password: 'mypassword'
    });
    token2 = await store.create({
      username: 'modiab',
      firstName: 'mo',
      lastName: 'diab',
      password: 'mypassword'
    });
    expect(typeof token1).toBeDefined;
    expect(typeof token1).toBeDefined;
    const payload1 = jwt.verify(token1, process.env.TOKEN_SECRET as string);
    const payload2 = jwt.verify(token2, process.env.TOKEN_SECRET as string);
    user1 = (payload1 as JwtPayload).user;
    user2 = (payload2 as JwtPayload).user;

    expect(user1.username).toBe('mohelmy');
    expect(user1.firstName).toBe('mo');
    expect(user1.lastName).toBe('helmy');

    expect(user2.username).toBe('modiab');
    expect(user2.firstName).toBe('mo');
    expect(user2.lastName).toBe('diab');
  });

  it('auth user', async () => {
    user1 = {
      username: 'mohelmy',
      password: 'mypassword'
    };
    user2 = {
      username: 'modiab',
      password: 'mypassword'
    };
    authUser1 = await store.authenticate(user1);
    authUser2 = await store.authenticate(user2);

    expect(authUser1.token).toBeDefined;
    expect(authUser1.authUser.username).toBe('mohelmy');
    expect(authUser1.authUser.firstName).toBe('mo');
    expect(authUser1.authUser.lastName).toBe('helmy');

    expect(authUser2.token).toBeDefined;
    expect(authUser2.authUser.username).toBe('modiab');
    expect(authUser2.authUser.firstName).toBe('mo');
    expect(authUser2.authUser.lastName).toBe('diab');
  });

  it('index all users', async () => {
    const result = await store.index();

    expect(result.length).toBe(2);

    expect(result[0].username).toBe('mohelmy');
    expect(result[0].firstName).toBe('mo');
    expect(result[0].lastName).toBe('helmy');

    expect(result[1].username).toBe('modiab');
    expect(result[1].firstName).toBe('mo');
    expect(result[1].lastName).toBe('diab');
  });

  it('show user by userId', async () => {
    user1 = await store.show(authUser1.authUser.id?.toLocaleString() as string);
    user2 = await store.show(authUser2.authUser.id?.toLocaleString() as string);

    expect(user1.username).toBe('mohelmy');
    expect(user1.firstName).toBe('mo');
    expect(user1.lastName).toBe('helmy');

    expect(user2.username).toBe('modiab');
    expect(user2.firstName).toBe('mo');
    expect(user2.lastName).toBe('diab');
  });
});
